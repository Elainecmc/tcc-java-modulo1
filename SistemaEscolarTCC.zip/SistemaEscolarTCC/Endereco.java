public class Endereco {
    // Atributos privados: só a própria classe pode mexer neles diretamente. Isso é o que chamamos de encapsulamento.
    private String logradouro;
    private int numero;

    // Construtor: é o método responsável por criar o objeto e já definir seus dados iniciais.
    public Endereco(String logradouro, int numero) {
        this.logradouro = logradouro;
        this.numero = numero;
    }

    // Getters: funcionam como uma “porta de acesso” segura para que outras classes possam consultar os dados, sem modificá-los.
    public String getLogradouro() { return logradouro; }
    public int getNumero() { return numero; }
}