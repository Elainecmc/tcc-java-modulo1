import java.util.Scanner;
import java.util.ArrayList; // Usado para armazenar vários alunos dinamicamente

// Classe principal do sistema escolar (onde o programa começa a executar)
public class SistemaEscolar {

    public static void main(String[] args) {

        // Scanner para ler os dados digitados pelo usuário
        Scanner leitor = new Scanner(System.in);

        // Lista que armazena todos os alunos cadastrados
        ArrayList<Aluno> listaAlunos = new ArrayList<>();

        // Variável usada para controlar a opção escolhida no menu
        int opcao = -1;

        // Laço do/while: mantém o menu funcionando até o usuário escolher sair
        do {
            System.out.println("\n========== MENU ESCOLAR ==========");
            System.out.println("1. Cadastrar Novo Aluno");
            System.out.println("2. Listar Alunos e Situações");
            System.out.println("0. Sair do Sistema");
            System.out.print("Escolha uma opção: ");
            
            opcao = leitor.nextInt();
            leitor.nextLine(); // Limpa o buffer após a leitura do número

            switch (opcao) {

                case 1:
                    // Coleta dos dados do aluno
                    System.out.print("Nome do Aluno: ");
                    String nome = leitor.nextLine();

                    System.out.print("CPF: ");
                    String cpf = leitor.nextLine();
                    
                    // Criando o objeto Endereco (Associação entre Aluno e Endereco)
                    System.out.print("Rua: ");
                    String rua = leitor.nextLine();
                    Endereco end = new Endereco(rua, 100);

                    // Criando o objeto Aluno com os dados informados
                    Aluno a = new Aluno(nome, cpf, end);

                    // Encapsulamento: usando métodos para definir nota e frequência
                    System.out.print("Nota Final (0-10): ");
                    a.setNota(leitor.nextDouble());

                    System.out.print("Frequência (0-100): ");
                    a.setFrequencia(leitor.nextInt());

                    // Adiciona o aluno na lista
                    listaAlunos.add(a);

                    System.out.println("Aluno salvo com sucesso!");
                    break;

                case 2:
                    System.out.println("\n--- RELATÓRIO FINAL ---");

                    // Percorre a lista de alunos e mostra nome e situação
                    for (Aluno aluno : listaAlunos) {
                        System.out.println("Nome: " + aluno.getNome() + 
                                         " | Situação: " + aluno.calcularSituacao());
                    }
                    break;

                case 0:
                    System.out.println("Saindo do sistema...");
                    break;

                default:
                    System.out.println("Opção inválida!");
            }

        } while (opcao != 0); // Continua executando até escolher sair

        // Fecha o Scanner para liberar recursos
        leitor.close();
    }
}
