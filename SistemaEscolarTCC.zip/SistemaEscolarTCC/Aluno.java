// "extends" indica que a classe Aluno herda as características da classe Pessoa.
public class Aluno extends Pessoa {
    private double nota;
    private int frequencia;

    public Aluno(String nome, String cpf, Endereco endereco) {
        // Aqui usamos super para chamar o construtor da classe Pessoa e inicializar os dados herdados (nome, CPF e endereço).
        super(nome, cpf, endereco); 
    }

    // Lógica de Negócio pedida no TCC
    public String calcularSituacao() {
        // Uso de operadores lógicos (&& significa E)
        if (this.nota >= 7.0 && this.frequencia >= 75) {
            return "APROVADO";
        } else if (this.frequencia < 75) {
            return "REPROVADO POR FALTA";
        } else {
            return "REPROVADO POR NOTA";
        }
    }

    // Encapsulamento: usamos métodos públicos para alterar as notas e faltas de forma controlada.
    public void setNota(double nota) { this.nota = nota; }
    public void setFrequencia(int frequencia) { this.frequencia = frequencia; }
    public double getNota() { return nota; }
}