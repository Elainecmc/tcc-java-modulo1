// A classe Disciplina representa uma matéria com nome e carga horária
public class Disciplina {

    // Atributos privados: protegidos para manter o encapsulamento
    private String nome;
    private int cargaHoraria;

    // Construtor: inicializa os dados da disciplina assim que o objeto é criado
    public Disciplina(String nome, int cargaHoraria) {
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
    }

    // Getter: permite acessar o nome da disciplina de forma segura
    public String getNome() { 
        return nome; 
    }
}
