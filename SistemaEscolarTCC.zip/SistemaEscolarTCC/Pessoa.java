public abstract class Pessoa {
    private String nome;
    private String cpf;
    private Endereco endereco; // Aqui vemos a associação entre as classes: a Pessoa possui um Endereço como parte de seus dados.

    // Construtor da classe base
    public Pessoa(String nome, String cpf, Endereco endereco) {
        this.nome = nome;
        this.cpf = cpf;
        this.endereco = endereco;
    }

    // Getters e Setters: permitem acessar e modificar os dados de forma controlada, mantendo a organização e segurança do código.
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getCpf() { return cpf; }
    
    public Endereco getEndereco() { return endereco; }
    public void setEndereco(Endereco endereco) { this.endereco = endereco; }
}