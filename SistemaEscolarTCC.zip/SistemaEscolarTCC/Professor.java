// A classe Professor herda as características da classe Pessoa
public class Professor extends Pessoa {

    // Atributo privado: armazena a especialidade do professor
    private String especialidade;

    // Construtor: cria o professor e já define seus dados no momento da criação
    public Professor(String nome, String cpf, Endereco endereco, String especialidade) {

        // Usamos super para enviar nome, cpf e endereço para o construtor de Pessoa
        super(nome, cpf, endereco);

        // Define a especialidade específica do professor
        this.especialidade = especialidade;
    }

    // Getter: permite acessar a especialidade de forma segura
    public String getEspecialidade() { 
        return especialidade; 
    }
}
